package com.crossoverjie.concurrent.communication;

/**
 * Function:
 *
 * @author crossoverJie
 * Date: 2019-04-17 20:26
 * @since JDK 1.8
 */
public interface Notify {

    /**
     * 回调
     */
    void notifyListen() ;
}
